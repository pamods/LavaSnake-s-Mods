/* 
READ ME:
So, you're attempting to play with code. Have fun and don't panic (much).
Now all should be good as long as you follow the below instructions. If 
these instructions aren't making sense then you probably should read the 
mod's description on the forums were all this is explained. Also, if you
have any problems just tell me on this mod's thread on the forums.	(These 
instructions are talking about the section indicated by the text saying 
"Things that are made to be changed")

How to change the flashing "timer done" colors:
	1. Go to the lines that start with "var FlashColor1" and "var FlashColor2"
	2. Change the text in the quotes to be the names of the two colors that you 
		want it to flash between.
		(You can use any of the colors listed on http://www.w3schools.com/html/html_colornames.asp
		or any RBG HEX value.)
		
How to change settings for one of the timers:
	1. Find the three lines that say "var Timer" and the number of the 
		timer you want to change.
	2. Follow one or more of these steps to change the settings:
		
		> To turn off/on or change the type of the timers:
			Set the value to the quotes following "...Type = " to:
				"Off" to remove it from the list
				"Normal" to make it a normal timer
				"Repeating" to make it a repeating task timer
				
		> To change the alert of a timer:
			Replace the text in the quotes following "...Alert = " with 
			whatever you want.
		
		> To change the duration of a timer:
			Replace the number following "...Dur = " with the number of 
			(whole) minutes that you want.
			
Feel free to play around with the rest of this too and I'm happy to explain any 
confusing code on the forums.
*/

//Things that are made to be changed:

var FlashColor1 = "red";
var FlashColor2 = "orange";

var Timer1Type = "Normal";
var Timer1Dur = 15;
var Timer1Alert = "0:00";

var Timer2Type = "Repeating";
var Timer2Dur = 15;
var Timer2Alert = "0:00";

var Timer3Type = "Off";
var Timer3Dur = 15;
var Timer3Alert = "0:00";

//You probably shouldn't touch the stuff below here unless you know what you're doing.

var Timer1State;
var Timer1Value;
var Timer2State;
var Timer2Value;
var Timer3State;
var Timer3Value;

//Set up Timers and GUI
document.body.innerHTML += '<div id="InGameTimersDiv" style="position: fixed; left: 20px; top: 200px;"></div>';
if (Timer1Type != "Off") {
	document.getElementById('InGameTimersDiv').innerHTML += '<p><input type="button" id="Timer1" data-bind="click: function (data, event) { TimerClick(1); }" value="Timer 1" /></p>';
	if (Timer1Type == "Normal") {
		Timer1State = "Off";
	} else if (Timer1Type == "Repeating") {
		Timer1State = "On";
		Timer1Value = 1;
	}
}
if (Timer2Type != "Off") {
	document.getElementById('InGameTimersDiv').innerHTML += '<p><input type="button" id="Timer2" data-bind="click: function (data, event) { TimerClick(2); }" value="Timer 2" /></p>';
	if (Timer2Type == "Normal") {
		Timer2State = "Off";
	} else if (Timer2Type == "Repeating") {
		Timer2State = "On";
		Timer2Value = 1;
	}
}
if (Timer3Type != "Off") {
	document.getElementById('InGameTimersDiv').innerHTML += '<p><input type="button" id="Timer3" data-bind="click: function (data, event) { TimerClick(3); }" value="Timer 3" /></p>';
	if (Timer3Type == "Normal") {
		Timer3State = "Off";
	} else if (Timer3Type == "Repeating") {
		Timer3State = "On";
		Timer3Value = 1;
	}
}
tick();

//Start Clock
window.setInterval(function(){tick()}, 1000);

//Runs every second
function tick() {
	if (Timer1State == "On") {
		Timer1Value -= 1;
		document.getElementById('Timer1').value = format(Timer1Value);
		if (Timer1Value == 0) {
			Timer1State = "Ringing.1";
			document.getElementById('Timer1').style.color = FlashColor1;
			document.getElementById('Timer1').value = Timer1Alert;
		}
	} else if (Timer1State == "Ringing.1") {
		Timer1State = "Ringing.2";
		document.getElementById('Timer1').style.color = FlashColor2;
	} else if (Timer1State == "Ringing.2") {
		Timer1State = "Ringing.1";
		document.getElementById('Timer1').style.color = FlashColor1;
	}
	
	if (Timer2State == "On") {
		Timer2Value -= 1;
		document.getElementById('Timer2').value = format(Timer2Value);
		if (Timer2Value == 0) {
			Timer2State = "Ringing.1";
			document.getElementById('Timer2').style.color = FlashColor1;
			document.getElementById('Timer2').value = Timer2Alert;
		}
	} else if (Timer2State == "Ringing.1") {
		Timer2State = "Ringing.2";
		document.getElementById('Timer2').style.color = FlashColor2;
	} else if (Timer2State == "Ringing.2") {
		Timer2State = "Ringing.1";
		document.getElementById('Timer2').style.color = FlashColor1;
	}
	
	if (Timer3State == "On") {
		Timer3Value -= 1;
		document.getElementById('Timer3').value = format(Timer3Value);
		if (Timer3Value == 0) {
			Timer3State = "Ringing.1";
			document.getElementById('Timer3').style.color = FlashColor1;
			document.getElementById('Timer3').value = Timer3Alert;
		}
	} else if (Timer3State == "Ringing.1") {
		Timer3State = "Ringing.2";
		document.getElementById('Timer3').style.color = FlashColor2;
	} else if (Timer3State == "Ringing.2") {
		Timer3State = "Ringing.1";
		document.getElementById('Timer3').style.color = FlashColor1;
	}
}

//Button click event
function TimerClick(Which) {
	if (Which == 1) {
		if (Timer1State == "On") {
			Timer1State = "Off";
			document.getElementById('Timer1').value = "Timer 1";
		} else if (Timer1State == "Off") {
			Timer1Value = Timer1Dur * 60;
			Timer1State = "On";
		} else if (Timer1State == "Ringing.1" || Timer1State == "Ringing.2") {
			document.getElementById('Timer1').style.color = "";
			if (Timer1Type == "Repeating") {
				Timer1Value = Timer1Dur * 60;
				Timer1State = "On";
			} else {
				Timer1State = "Off";
				document.getElementById('Timer1').value = "Timer 1";
			}
		}
	} else if (Which == 2) {
		if (Timer2State == "On") {
			Timer2State = "Off";
			document.getElementById('Timer2').value = "Timer 2";
		} else if (Timer2State == "Off") {
			Timer2Value = Timer2Dur * 60;
			Timer2State = "On";
		} else if (Timer2State == "Ringing.2" || Timer2State == "Ringing.2") {
			document.getElementById('Timer2').style.color = "";
			if (Timer2Type == "Repeating") {
				Timer2Value = Timer2Dur * 60;
				Timer2State = "On";
			} else {
				Timer2State = "Off";
				document.getElementById('Timer2').value = "Timer 2";
			}
		}
	} else if (Which == 3) {
		if (Timer3State == "On") {
			Timer3State = "Off";
			document.getElementById('Timer3').value = "Timer 3";
		} else if (Timer3State == "Off") {
			Timer3Value = Timer3Dur * 60;
			Timer3State = "On";
		} else if (Timer3State == "Ringing.3" || Timer3State == "Ringing.2") {
			document.getElementById('Timer3').style.color = "";
			if (Timer3Type == "Repeating") {
				Timer3Value = Timer3Dur * 60;
				Timer3State = "On";
			} else {
				Timer3State = "Off";
				document.getElementById('Timer3').value = "Timer 3";
			}
		}
	}
}

//Turns an amount of seconds into Minutes:Seconds
function format(Secs) {
	var Minutes = parseInt(Secs / 60);
	var SecondsLeft = String(Secs - (Minutes * 60));
	if (SecondsLeft.length == 1) { SecondsLeft = "0" + SecondsLeft; }
	return Minutes + ":" + SecondsLeft;
}