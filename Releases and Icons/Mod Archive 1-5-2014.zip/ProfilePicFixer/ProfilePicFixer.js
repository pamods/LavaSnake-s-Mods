var elements = document.getElementsByClassName("div_start_menu_profile_pic");

elements[0].style.background = "url(../../mods/ProfilePicFixer/pic.png) center center #333";
elements[0].style.backgroundSize = "80px 80px";

var DoAwesome = Math.floor((Math.random()*3)+1);

if (DoAwesome == 3) {
	var Awesome = "";
	var WhatAwesome = Math.floor((Math.random()*10)+1);
	
	if (WhatAwesome == 1) {
		Awesome = "Don't lose!";
	} else if (WhatAwesome == 2) {
		Awesome = "PA is awesome!";
	} else if (WhatAwesome == 3) {
		Awesome = "It's in beta for a reason.";
	} else if (WhatAwesome == 4) {
		Awesome = "Nice profile pic!";
	} else if (WhatAwesome == 5) {
		Awesome = "Randomness can be beneficial.";
	} else if (WhatAwesome == 6) {
		Awesome = "That AI is scaring me.";
	} else if (WhatAwesome == 7) {
		Awesome = "Go Uber!";
	} else if (WhatAwesome == 8) {
		Awesome = "Throw the asteroid!";
	} else if (WhatAwesome == 9) {
		Awesome = "New UI is coming soon!";
	} else {
		elements[0].style.background = "url(../../mods/ProfilePicFixer/a.gif) center center #333";
		elements[0].style.backgroundSize = "80px 80px";
		Awesome = "SO AWESOME!!!";
	}
	
	$('#A12').parent().parent().parent().before(
		'<tr><td class="td_start_menu_item"><span class="link_start_menu_item"><a href="#" id="A8" data-bind="click_sound: \'default\', rollover_sound: \'default\'"><span class="start_menu_item_lbl" style="color: black;">'
		+ Awesome + 
		'</span></a></span></td></tr>');
}