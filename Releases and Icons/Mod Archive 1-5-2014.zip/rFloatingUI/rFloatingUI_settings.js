//Build number
model.registerFrameSetting('version_info_frame', 'VERSION INFO', true);

//Player List
model.registerFrameSetting('player_list_frame', 'PLAYER LIST', true);

//Chrono Cam Icon
model.registerFrameSetting('chrono_icon_frame', 'CHRONO CAM ICON', true);
