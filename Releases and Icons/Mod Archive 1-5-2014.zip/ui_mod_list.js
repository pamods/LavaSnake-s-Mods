/* Anchor Buttons */
/* Build Power */
/* PA Stats Tracker Online Version */
/* Planet Preview Details */
/* Profile Pic Fixer */
/* Commander Health Display */
/* Floating Framework */
/* Installed Mods List */
/* Settings Manager */
/* Unit Info */

var rModsList = [{'name': 'Anchor Buttons', 'author': 'burntcustard,PRoeleert', 'version': '1.2', 'build': '58197', 'category': 'In-Game'},{'name': 'Build Power', 'author': 'ORFJackal', 'version': '1.0.0', 'build': '58772', 'category': 'In-Game'},{'name': 'PA Stats Tracker Online Version', 'author': 'Cola_Colin, Gunshin', 'version': 'updates_automatically', 'build': 'I_will_keep_this_updated', 'category': 'Statistics Tracking'},{'name': 'Planet Preview Details', 'author': 'Dementiurge', 'version': '1.0', 'build': '57703', 'category': 'New Game,Lobby'},{'name': 'Profile Pic Fixer', 'author': 'LavaSnake', 'version': '1.1', 'build': '56516 and up', 'category': 'Main Menu'},{'name': 'Commander Health Display', 'author': 'raevn, danzel, burntcustard', 'version': '2.7.1', 'build': '58197', 'category': 'In-Game'},{'name': 'Floating Framework', 'author': 'raevn', 'version': '1.2.1', 'build': '58197', 'category': 'Framework'},{'name': 'Installed Mods List', 'author': 'raevn', 'version': '1.2.1', 'build': '58197', 'category': 'Main Menu'},{'name': 'Settings Manager', 'author': 'raevn', 'version': '1.1', 'build': '58197', 'category': 'Framework'},{'name': 'Unit Info', 'author': 'raevn', 'version': '1.1.0', 'build': '56516', 'category': 'In-Game'}];

/* start ui_mod_list */
var global_mod_list = [
'../../mods/rSettingsManager/rSettingsManager_global.js',
'../../mods/rFloatFrame/rFloatFrame.css',
'../../mods/rFloatFrame/rFloatFrame.js',
'http://www.nanodesu.info/stuff/pa/mods/live/pastats/pa_stats_loader.js',
'../../mods/bAnchorButtons/global_mod_list/bAnchorButtons_Global.js'
];
var scene_mod_list = {'connect_to_game': [

],'game_over': [

],
'icon_atlas': [

],
'live_game': [
'../../mods/rUnitInfo/rUnitInfo.js',
'../../mods/rUnitInfo/rUnitInfo.css',
'../../mods/rCommanderHP/rCommanderHP.css',
'../../mods/rCommanderHP/rCommanderHP.js',
'../../mods/BuildPower/core.js',
'../../mods/BuildPower/init.js',
'../../mods/bAnchorButtons/live_game/bAnchorButtons.css',
'../../mods/bAnchorButtons/live_game/bAnchorButtons.js'
],
'load_planet': [

],
'lobby': [
'../../mods/planetpreview/pp_lobby.js'
],
'matchmaking': [

],
'new_game': [
'../../mods/planetpreview/pp_newgame.js'
],
'server_browser': [

],
'settings': [
'../../mods/rSettingsManager/rSettingsManager.js',
'../../mods/rSettingsManager/rSettingsManager.css',
'../../mods/rFloatFrame/rFloatFrame_settings.js',
'../../mods/rCommanderHP/rCommanderHP_settings.js',
'../../mods/bAnchorButtons/settings/bAnchorButtons_Settings.js'
],
'special_icon_atlas': [

],
'start': [
'../../mods/rModsList/rModsList.js',
'../../mods/rModsList/rModsList.css',
'../../mods/ProfilePicFixer/ProfilePicFixer.js'
],
'system_editor': [

],
'transit': [

]
}
/* end ui_mod_list */
