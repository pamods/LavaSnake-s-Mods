//Setup storage if first time
if (!window.localStorage.LTimers_Timer1Type) {
	window.localStorage.LTimers_Timer1Type = "Off";
	window.localStorage.LTimers_Timer1Dur = 15;
	window.localStorage.LTimers_Timer1Alert = "0:00";
	
	window.localStorage.LTimers_Timer2Type = "Off";
	window.localStorage.LTimers_Timer2Dur = 15;
	window.localStorage.LTimers_Timer2Alert = "0:00";
	
	window.localStorage.LTimers_Timer3Type = "Off";
	window.localStorage.LTimers_Timer3Dur = 15;
	window.localStorage.LTimers_Timer3Alert = "0:00";
}

var FlashColor1 = "red";
var FlashColor2 = "orange";

var Timer1State;
var Timer1Value;

var Timer2State;
var Timer2Value;

var Timer3State;
var Timer3Value;

//Set up Timers and GUI
createFloatingFrame("InGameTimersDiv", 175, 150, {'top': 250});
$('body').append('<span id="TimerConfigSpan"></span>');

document.getElementById('InGameTimersDiv_content').innerHTML += '<p><input type="button" oncontextmenu="Config(1);" id="Timer1" data-bind="click: function (data, event) { TimerClick(1); }" value="Timer 1" /></p>';
if (window.localStorage.LTimers_Timer1Type == "Normal") {
	Timer1State = "Off";
} else if (window.localStorage.LTimers_Timer1Type == "Repeating") {
	Timer1State = "On";
	Timer1Value = 1;
} else if (window.localStorage.LTimers_Timer1Type == "Off") {
	Timer1State = "Off";
	document.getElementById('Timer1').value = "Right click to set";
}

document.getElementById('InGameTimersDiv_content').innerHTML += '<p><input type="button" oncontextmenu="Config(2);" id="Timer2" data-bind="click: function (data, event) { TimerClick(2); }" value="Timer 2" /></p>';
if (window.localStorage.LTimers_Timer2Type == "Normal") {
	Timer2State = "Off";
} else if (window.localStorage.LTimers_Timer2Type == "Repeating") {
	Timer2State = "On";
	Timer2Value = 1;
} else if (window.localStorage.LTimers_Timer2Type == "Off") {
	Timer2State = "Off";
	document.getElementById('Timer2').value = "Right click to set";
}

document.getElementById('InGameTimersDiv_content').innerHTML += '<p><input type="button" oncontextmenu="Config(3);" id="Timer3" data-bind="click: function (data, event) { TimerClick(3); }" value="Timer 3" /></p>';
if (window.localStorage.LTimers_Timer3Type == "Normal") {
	Timer3State = "Off";
} else if (window.localStorage.LTimers_Timer3Type == "Repeating") {
	Timer3State = "On";
	Timer3Value = 1;
} else if (window.localStorage.LTimers_Timer3Type == "Off") {
	Timer3State = "Off";
	document.getElementById('Timer3').value = "Right click to set";
}

tick();

//Start Clock
window.setInterval(function(){tick()}, 1000);

//Runs every second
function tick() {
	if (Timer1State == "On") {
		Timer1Value -= 1;
		document.getElementById('Timer1').value = format(Timer1Value);
		if (Timer1Value == 0) {
			Timer1State = "Ringing.1";
			document.getElementById('Timer1').style.color = FlashColor1;
			document.getElementById('Timer1').value = window.localStorage.LTimers_Timer1Alert;
		}
	} else if (Timer1State == "Ringing.1") {
		Timer1State = "Ringing.2";
		document.getElementById('Timer1').style.color = FlashColor2;
	} else if (Timer1State == "Ringing.2") {
		Timer1State = "Ringing.1";
		document.getElementById('Timer1').style.color = FlashColor1;
	}
	
	if (Timer2State == "On") {
		Timer2Value -= 1;
		document.getElementById('Timer2').value = format(Timer2Value);
		if (Timer2Value == 0) {
			Timer2State = "Ringing.1";
			document.getElementById('Timer2').style.color = FlashColor1;
			document.getElementById('Timer2').value = window.localStorage.LTimers_Timer2Alert;
		}
	} else if (Timer2State == "Ringing.1") {
		Timer2State = "Ringing.2";
		document.getElementById('Timer2').style.color = FlashColor2;
	} else if (Timer2State == "Ringing.2") {
		Timer2State = "Ringing.1";
		document.getElementById('Timer2').style.color = FlashColor1;
	}
	
	if (Timer3State == "On") {
		Timer3Value -= 1;
		document.getElementById('Timer3').value = format(Timer3Value);
		if (Timer3Value == 0) {
			Timer3State = "Ringing.1";
			document.getElementById('Timer3').style.color = FlashColor1;
			document.getElementById('Timer3').value = window.localStorage.LTimers_Timer3Alert;
		}
	} else if (Timer3State == "Ringing.1") {
		Timer3State = "Ringing.2";
		document.getElementById('Timer3').style.color = FlashColor2;
	} else if (Timer3State == "Ringing.2") {
		Timer3State = "Ringing.1";
		document.getElementById('Timer3').style.color = FlashColor1;
	}
}

//Button click event
function TimerClick(Which) {
	if (Which == 1 && window.localStorage.LTimers_Timer1Type != "Off") {
		if (Timer1State == "On") {
			Timer1State = "Off";
			document.getElementById('Timer1').value = "Timer 1";
		} else if (Timer1State == "Off") {
			Timer1Value = window.localStorage.LTimers_Timer1Dur * 60;
			Timer1State = "On";
		} else if (Timer1State == "Ringing.1" || Timer1State == "Ringing.2") {
			document.getElementById('Timer1').style.color = "";
			if (window.localStorage.LTimers_Timer1Type == "Repeating") {
				Timer1Value = window.localStorage.LTimers_Timer1Dur * 60;
				Timer1State = "On";
			} else {
				Timer1State = "Off";
				document.getElementById('Timer1').value = "Timer 1";
			}
		}
	} else if (Which == 2 && window.localStorage.LTimers_Timer2Type != "Off") {
		if (Timer2State == "On") {
			Timer2State = "Off";
			document.getElementById('Timer2').value = "Timer 2";
		} else if (Timer2State == "Off") {
			Timer2Value = window.localStorage.LTimers_Timer2Dur * 60;
			Timer2State = "On";
		} else if (Timer2State == "Ringing.2" || Timer2State == "Ringing.2") {
			document.getElementById('Timer2').style.color = "";
			if (window.localStorage.LTimers_Timer2Type == "Repeating") {
				Timer2Value = window.localStorage.LTimers_Timer2Dur * 60;
				Timer2State = "On";
			} else {
				Timer2State = "Off";
				document.getElementById('Timer2').value = "Timer 2";
			}
		}
	} else if (Which == 3 && window.localStorage.LTimers_Timer3Type != "Off") {
		if (Timer3State == "On") {
			Timer3State = "Off";
			document.getElementById('Timer3').value = "Timer 3";
		} else if (Timer3State == "Off") {
			Timer3Value = window.localStorage.LTimers_Timer3Dur * 60;
			Timer3State = "On";
		} else if (Timer3State == "Ringing.3" || Timer3State == "Ringing.2") {
			document.getElementById('Timer3').style.color = "";
			if (window.localStorage.LTimers_Timer3Type == "Repeating") {
				Timer3Value = window.localStorage.LTimers_Timer3Dur * 60;
				Timer3State = "On";
			} else {
				Timer3State = "Off";
				document.getElementById('Timer3').value = "Timer 3";
			}
		}
	}
}

//Handle the configuration of timers
function Config(Which) {
	//Get current data
	var Types;
	var Dur;
	var Alert;
	if (Which == 1) {
		Alert = window.localStorage.LTimers_Timer1Alert;
		Dur = window.localStorage.LTimers_Timer1Dur;
		if (window.localStorage.LTimers_Timer1Type == "Off") {
			Types = '<option selected="selected">Off</option><option>Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer1Type == "Normal") {
			Types = '<option>Off</option><option selected="selected">Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer1Type == "Repeating") {
			Types = '<option>Off</option><option>Normal</option><option selected="selected">Repeating</option>';
		}
	} else if (Which == 2) {
		Alert = window.localStorage.LTimers_Timer2Alert;
		Dur = window.localStorage.LTimers_Timer2Dur;
		if (window.localStorage.LTimers_Timer2Type == "Off") {
			Types = '<option selected="selected">Off</option><option>Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer2Type == "Normal") {
			Types = '<option>Off</option><option selected="selected">Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer2Type == "Repeating") {
			Types = '<option>Off</option><option>Normal</option><option selected="selected">Repeating</option>';
		}
	} else if (Which == 3) {
		Alert = window.localStorage.LTimers_Timer3Alert;
		Dur = window.localStorage.LTimers_Timer3Dur;
		if (window.localStorage.LTimers_Timer3Type == "Off") {
			Types = '<option selected="selected">Off</option><option>Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer3Type == "Normal") {
			Types = '<option>Off</option><option selected="selected">Normal</option><option>Repeating</option>';
		} else if (window.localStorage.LTimers_Timer3Type == "Repeating") {
			Types = '<option>Off</option><option>Normal</option><option selected="selected">Repeating</option>';
		}
	}
	
	//Show dialog
	document.getElementById('TimerConfigSpan').innerHTML = 
		'<div style="margin: 0px auto; position: absolute; background: rgba(0,0,0,.5); padding: 10px; left: 20px; top: 200px; right: 20px; height: 300px; width: 250px; border: 1px solid rgba(255,255,255,.1);	border-radius: 4px;">' +
			'<div style="margin: 0px 0px 4px 0px; font-weight: bold; font-size: 1.2em;"> CONFIGURATION FOR TIMER ' + Which + 
				'<a data-bind="click_sound: \'default\'" onclick="document.getElementById(\'TimerConfigSpan\').innerHTML = \'\';"><img style="float:right;" src="../shared/img/close_btn.png"></a>' +
			'</div>' +
			'<p>Mode: ' +
				'<select onchange="window.localStorage.LTimers_Timer' + Which + 'Type = this.options[this.selectedIndex].value;">' +
					Types +
				'</select>' +
			'</p>' +
			'<p>Duration: ' +
				'<input style="width: 75px;" type="text" value="' + Dur + '" onchange="window.localStorage.LTimers_Timer' + Which + 'Dur = this.value">' +
			' minutes</p>' +
			'<p>Text to display when done: ' +
				'<input style="width: 75px;" type="text" value="' + Alert + '" onchange="window.localStorage.LTimers_Timer' + Which + 'Alert = this.value">' +
			'</p>' +
		'</div>';
}

//Turns an amount of seconds into Minutes:Seconds
function format(Secs) {
	var Minutes = parseInt(Secs / 60);
	var SecondsLeft = String(Secs - (Minutes * 60));
	if (SecondsLeft.length == 1) { SecondsLeft = "0" + SecondsLeft; }
	return Minutes + ":" + SecondsLeft;
}