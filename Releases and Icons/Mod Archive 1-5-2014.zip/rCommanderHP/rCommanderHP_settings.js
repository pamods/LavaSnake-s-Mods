model.addSetting_DropDown('SHOW HP DISPLAY', 'commander_hp_display_show', 'UI', ['ALWAYS', 'UNDER ATTACK'], 0);
model.registerFrameSetting('commander_info_frame', 'COMMANDER HP', true);