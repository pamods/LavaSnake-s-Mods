model.addSetting_DropDown('Show Unit Group Buttons','bAnchorButtonsUnitsVisible','UI',["ON","OFF"],1);
model.addSetting_Text('Nr of Anchor Buttons','bAnchorButtonsAmount','UI','Number',8);
model.addSetting_Text('Nr of Unit Groups Buttons','bAnchorButtonsUnitsAmount','UI','Number',8);
model.registerFrameSetting('bAnchorButtons_info_frame', 'Anchor Buttons', true);