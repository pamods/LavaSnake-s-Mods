initialSettingValue('bAnchorButtonsAmount',8);
initialSettingValue('bAnchorButtonsUnitsAmount',8);
initialSettingValue('bAnchorButtonsUnitsVisible','OFF');