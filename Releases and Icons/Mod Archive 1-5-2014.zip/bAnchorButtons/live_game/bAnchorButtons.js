//load html dynamically
function loadAnchorHtmlTemplate(element, url) {
    element.load(url, function () {
        console.log("Loading html " + url);
        ko.applyBindings(model, element.get(0));
    });
}


var settings = decode(localStorage.settings);

//debugger;
model.bAnchorButtonsAmount = ko.observable(parseInt(settings.bAnchorButtonsAmount));
model.bAnchorButtonsUnitsAmount = ko.observable(parseInt(settings.bAnchorButtonsUnitsAmount));

if (isNaN(model.bAnchorButtonsAmount())) {
    model.bAnchorButtonsAmount(8);
}
if(model.bAnchorButtonsAmount() > 8)
{
    model.bAnchorButtonsAmount(8);
}

model.bAnchorButtonsArr = ko.observableArray([]);
for (var i = 0; i < model.bAnchorButtonsAmount(); i++)
{
    model.bAnchorButtonsArr().push(i+1);
}

if (isNaN(model.bAnchorButtonsUnitsAmount())) {
    model.bAnchorButtonsUnitsAmount(8);
}
if(model.bAnchorButtonsUnitsAmount() > 8)
{
    model.bAnchorButtonsUnitsAmount(8);
}

model.bAnchorButtonsUnitsArr = ko.observableArray([]);
for (var i = 0; i < model.bAnchorButtonsUnitsAmount(); i++)
{
    model.bAnchorButtonsUnitsArr().push(i+1);
}

model.bAnchorButtonsUnitsVisible = ko.computed(function () {
    if (settings.bAnchorButtonsUnitsVisible == "ON") {
        return true;
    }
    else {
        return false;
    }
});

//forgetFramePosition('bAnchorButtons_info_frame');

createFloatingFrame('bAnchorButtons_info_frame', 220, 70, {'offset': 'topCenter', 'top':42});
loadAnchorHtmlTemplate($('#bAnchorButtons_info_frame_content'), '../../mods/bAnchorButtons/live_game/bAnchorButtons.html');