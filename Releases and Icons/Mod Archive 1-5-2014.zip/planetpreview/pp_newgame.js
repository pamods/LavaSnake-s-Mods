/* VARIABLES
------------------------------------ */
var $pp_newgamedivplanettable = $( ".div_planet_selector_tbl" );
/* FUNCTIONS
------------------------------------ */
model.pp_seedString = function (index) {
	var seedVar = model.loadedSystem().planets[index].planet.seed;
	return "Seed: " + seedVar;
	}

	model.pp_planetBiomeString = function (value) {
	return value + " - ";
	}

model.pp_planetDiameterString = function (value) {
	return (2 * value) + "m";
	}

model.pp_planetRadiusString = function (value) {
	return "Radius: " + value + "m";
	}

model.pp_planetSeedString = function (value) {
	return "Seed # " + value;
	}

model.pp_planetBiomeScaleString = function (value) {
	return "Biome Scale: " + value;
	}

model.pp_planetHeightRangeString = function (value) {
	return "Height Range: " + value;
	}

model.pp_planetWaterHeightString = function (value) {
	return "Water Height: " + value;
	}

model.pp_planetTemperatureString = function (value) {
	return "Temperature: " + value;
	}

model.pp_getRandomSeed = function (inum) {
	var syst = model.loadedSystem();
	var plans = model.loadedSystem().planets;
	var randomNum = Math.floor(Math.random() * (32767 + 1));
	plans[inum].planet.seed = randomNum;
	
    syst.planets = plans;
    model.loadedSystem(syst);
	}


/* INNER HTML
------------------------------------ */
var $pp_newgame_planet_tbl = $( '<table class="div_planet_selector_tbl" style="width:90%;"> \
	<tbody data-bind="foreach: loadedSystem().planets"> \
		<tr> \
			<td> \
				<img style="margin-right:8px;" height="56px" width="56px" data-bind="attr: { src: model.imageSourceForPlanet($data.planet) }" /> \
			</td> \
			<td> \
				<div class="input_label" data-bind="visible: $index() === 0">STARTING PLANET: </div> \
				<div class="input_field_static" style="text-transform:uppercase;" data-bind="text: name"></div> \
				<div> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetBiomeString($data.planet.biome)"></span> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetDiameterString($data.planet.radius)"></span> \
				</div> \
				<div data-bind="visible: $index() > 0">\
					<a href="#" class="text_link_btn text_link_btn_small" data-bind="click: function () { model.setPrimaryPlanet($index()); }, \
																					 click_sound:' + "'default', \
																					 rollover_sound: 'default'" + '">Set As Starting Planet \
					</a> \
				</div> \
			</td> \
		</tr> \
		<tr> \
			<td> \
				<a href="#" class="text_link_btn" style="font-size:0.7em" onClick="$( this ).parent().next().children().show(); $( this ).next().show(); $( this ).hide();" data-bind="click_sound:' + "'default', rollover_sound: 'default'" + '">Show Details</a> \
				<a href="#" class="text_link_btn" style="font-size:0.7em;display:none;" onClick="$( this ).parent().next().children().hide(); $( this ).prev().show(); $( this ).hide();" data-bind="click_sound:' + "'default', rollover_sound: 'default'" + '">Hide Details</a> \
			</td> \
			<td> \
				<div style="display:none;line-height:0.75em;margin-bottom:0.5em;"> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_seedString($index())"></span> \
					<a href="#" class="text_link_btn text_link_btn_small" data-bind="click: function () { model.pp_getRandomSeed($index()); }, \
																					 click_sound:' + "'default', \
																					 rollover_sound: 'default'" + '">New Seed \
					</a> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetRadiusString($data.planet.radius)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetBiomeScaleString($data.planet.biomeScale)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetHeightRangeString($data.planet.heightRange)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetWaterHeightString($data.planet.waterHeight)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetTemperatureString($data.planet.temperature)"></span> \
					<br> \
				</div> \
			</td> \
		</tr> \
	</tbody> \
</table>' );

/* MODIFY DOM
------------------------------------ */
$( $pp_newgamedivplanettable ).replaceWith( $pp_newgame_planet_tbl );