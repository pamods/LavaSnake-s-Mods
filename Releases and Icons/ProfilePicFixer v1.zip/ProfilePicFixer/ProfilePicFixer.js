var elements = document.getElementsByClassName("div_start_menu_profile_pic");

elements[0].style.background = "url(../../mods/ProfilePicFixer/pic.png) center center #333";
elements[0].style.backgroundSize = "80px 80px";